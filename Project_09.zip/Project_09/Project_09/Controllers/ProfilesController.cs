﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using Project_09.Data;
using Project_09.ViewModels;

namespace Project_09.Controllers
{
    public class ProfilesController : Controller
    {
        //ApplicationDbContext context = new ApplicationDbContext();
        public UserManager<ApplicationUser> userManager;
        private readonly IHostingEnvironment hosting;
        public ProfilesController(UserManager<ApplicationUser> userManager, IHostingEnvironment host)
        {
            this.userManager = userManager;
            this.hosting = host;
        }
        public async Task<IActionResult> Index()
        {
            var userId = userManager.GetUserId(HttpContext.User);
            var user =await userManager.FindByIdAsync(userId);
            ProfileVm profileVm = new ProfileVm
            {
                UserName = user.UserName,
                Email = user.Email,
                Phonenumber = user.PhoneNumber,
                Dob = user.Dob,
                Address = user.Address,
                Fullname = user.Fullname,
                ImagePath = user.ImagePath,
                UserId = user.Id
            };
            return View(profileVm);
        }
        public async Task<IActionResult> Edit(string uid)
        {
            //var userId = userManager.GetUserId(HttpContext.User);
            var user =await userManager.FindByIdAsync(uid);
            if (user == null)
            {
                ViewBag.ErrorMessage = $"User with Id={uid} cannot be found";
                return View("NotFound");
            }
            ProfileVm profileVm = new ProfileVm
            {
                UserName = user.UserName,
                Email = user.Email,
                Phonenumber = user.PhoneNumber,
                Dob = user.Dob,
                ImagePath = user.ImagePath,
                Address = user.Address,
                Fullname = user.Fullname,
                UserId = user.Id,
                Pass = user.PasswordHash,
                SecStamp = user.SecurityStamp
            };
            return View(profileVm);
        }
        [HttpPost]
        public async Task<IActionResult> Edit(ProfileVm vm)
        {
            var user =await userManager.FindByIdAsync(vm.UserId);
            if (user == null)
            {
                ViewBag.ErrorMessage = $"User with Id = {vm.UserId} cannot be found";
                return View("NotFound");
            }
            else
            {
                if (vm.ImgFile != null)
                {
                    string ext = Path.GetExtension(vm.ImgFile.FileName).ToLower();
                    if (ext == ".jpg" || ext == ".jpeg" || ext == ".png")
                    {
                        var filename = Path.GetFileName(vm.ImgFile.FileName);
                        var filepath = Path.Combine(hosting.WebRootPath, "images\\Upload", filename);
                        using(var filestream=new FileStream(filepath, FileMode.Create))
                        {
                            vm.ImgFile.CopyTo(filestream);
                            user.ImagePath = "\\images\\Upload\\" + vm.ImgFile.FileName;
                        }
                    }
                }
                user.Address = vm.Address;
                user.PhoneNumber = vm.Phonenumber;
                user.Fullname = vm.Fullname;
                user.UserName = vm.UserName;
                user.Dob = vm.Dob;
                var result = await userManager.UpdateAsync(user);
                if (result.Succeeded)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    foreach(var e in result.Errors)
                    {
                        ViewBag.result = e.Description;
                    }
                }
                return View(vm);
            }
        }
    }
}