﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Project_09.Data;
using Project_09.ViewModels;

namespace Project_09.Controllers
{
    [Authorize]
    public class ManageRoleController : Controller
    {
        public RoleManager<IdentityRole> rolemanager;
        public UserManager<ApplicationUser> userManager;
        public ManageRoleController(RoleManager<IdentityRole> role, UserManager<ApplicationUser> user)
        {
            this.rolemanager = role;
            this.userManager = user;
        }
       
       public async Task<IActionResult> AssignRole(string Userlist,string Rolelist)
        {
            try
            {
                var list = userManager.Users.ToList();
                ViewBag.Userlist = new SelectList(list, "Id", "UserName");
                ViewBag.Rolelist = new SelectList(rolemanager.Roles, "Name", "Name");
                var user = await userManager.FindByIdAsync(Userlist);
                IdentityResult result = await userManager.AddToRoleAsync(user, Rolelist);
                if (result.Succeeded)
                {
                    ViewBag.result = user.UserName + "successfully assign to role" + Rolelist;
                }
                if (result.Errors.Count() > 0)
                {
                    foreach (var s in result.Errors)
                    {
                        ModelState.AddModelError("", s.ToString());
                    }
                }

            }
            catch(Exception ex)
            {
                ViewBag.result = ex.Message;
            }
            return View("DisplayRoleuser");
        }
        public async Task<IActionResult> AllRoles()
        {
            List<UsersRole> usersRoleslist = new List<UsersRole>();
            var users = userManager.Users.ToList();
            string rolename = "";
            foreach(var v in users)
            {
                UsersRole usersVM = new UsersRole();
                var roles = await userManager.GetRolesAsync(v);
                foreach(var r in roles)
                {
                    rolename = string.Join(",", r);
                }
                usersVM.UserName = v.UserName;
                usersVM.RoleName = rolename;
                usersRoleslist.Add(usersVM);
            }
            return View(usersRoleslist);
        }
        public IActionResult DisplayRoleuser()
        {
            try
            {
                var list = userManager.Users.ToList();
                ViewBag.Userlist = new SelectList(list, "Id", "UserName");
                ViewBag.Rolelist = new SelectList(rolemanager.Roles, "Name", "Name");
            }
            catch(Exception ex)
            {

            }
            return View();
        }
        public IActionResult Index()
        {
            return View(rolemanager.Roles.ToList());
        }
        [Authorize(Policy ="userOp")]
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(RolesVM vM)
        {
            IdentityRole identityRole = new IdentityRole
            {
                Name = vM.Name,
            };
            if(ModelState.IsValid)
            {
                IdentityResult result = await rolemanager.CreateAsync(identityRole);
                if (result.Succeeded)
                {
                    return RedirectToAction("Index");
                }
                if (result.Errors.Count() > 0)
                {
                    foreach(var s in result.Errors)
                    {
                        ModelState.AddModelError("", s.ToString());
                    }
                }
            }
            return View(identityRole);
        }
        [HttpGet]
        public async Task <IActionResult> DisplayClaims()
        {
            var claimVm = new ClaimsVm
            {
                Email = ""
            };
            try
            {
                var list = userManager.Users.ToList();
                ViewBag.Userlist = new SelectList(list, "UserName", "UserName");
                var allClaims = ClaimStore.GetClaims;
                var user = await userManager.FindByEmailAsync(claimVm.Email);
                if (user == null)
                {
                    foreach(var c in allClaims)
                    {
                        UserClaims userClaims = new UserClaims
                        {
                            ClaimType = c.Type,
                            Isselected = false
                        };
                        claimVm.UserClaims.Add(userClaims);
                    }
                }
                else
                {
                    var existingClaim =await userManager.GetClaimsAsync(user);
                    foreach(var c in allClaims)
                    {
                        UserClaims userClaims = new UserClaims
                        {
                            ClaimType = c.Type,
                        };
                        if (existingClaim.Any(a => a.Type == c.Type))
                        {
                            userClaims.Isselected = true;
                        }
                        claimVm.UserClaims.Add(userClaims);
                    }
                }
            }
            catch(Exception ex)
            {
                ViewBag.result = ex.Message;
            }
            return View(claimVm);
        }
        [HttpPost]
        public async Task<IActionResult> DisplayClaims(ClaimsVm vm,string Userlist)
        {
            var user = await userManager.FindByEmailAsync(Userlist);
            var existingClaim = await userManager.GetClaimsAsync(user);
            foreach(var c in existingClaim)
            {
                await userManager.RemoveClaimAsync(user, c);
            }
            foreach(var c in vm.UserClaims)
            {
                if (c.Isselected)
                {
                    IdentityResult result =await userManager.AddClaimAsync(user, new Claim(c.ClaimType, c.ClaimType));
                    if (result.Succeeded)
                    {
                        ViewBag.Result = "Selected claim on" + vm.Email + "successfully assigned";
                    }
                }
            }
            return View(vm);

        }


    }
}