﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Project_09.Data;
using Project_09.Models;
using Project_09.Viewmodels;

namespace Project_09.Controllers
{
    public class EmployeesController : Controller
    {
        public readonly ApplicationDbContext db;
        public readonly IHostingEnvironment hosting;
        public EmployeesController(IHostingEnvironment host, ApplicationDbContext _db)
        {
            this.hosting = host;
            this.db = _db;
        }
        public  IActionResult Index()
        {
             
            return View();
        }
        public JsonResult Get()
        {
            var data = db.Employees.ToList();
            return Json(data);
        }
        [HttpPost]
        public IActionResult AddEmployee(EmployeeVM vm, IEnumerable<IFormFile> files)
        {
            if (!ModelState.IsValid)
            {
                ModelState.AddModelError("", "Invalid Model");
                var message = string.Join(" | ", ModelState.Values
        .SelectMany(v => v.Errors)
        .Select(e => e.ErrorMessage));
                return View("Index", message);
            }

            string uploadpath = Path.Combine(hosting.WebRootPath, "images");
            Employee employee = new Employee
            {
                EmployeeName = vm.EmployeeName,
                Gender = vm.Gender,
                DateOfBirth = vm.DateOfBirth,
                Salary=vm.Salary,
                PhoneNumber=vm.PhoneNumber,
                Email=vm.Email,
                

            };
            foreach (var file in files)
            {
                if (file != null && file.Length > 0)
                {
                    var fileName = Guid.NewGuid().ToString() +
                                   file.FileName;
                    using (var s = new FileStream(Path.Combine(uploadpath, fileName),
                                                                FileMode.Create))
                    {
                        file.CopyTo(s);
                        employee.ImagePath= "/images/" + fileName;

                    }
                }
            }


            db.Employees.Add(employee);
            if (db.SaveChanges() > 0)
            {
                return Json(new { result = "success" });
            }
            else
            {
                return Json(new { result = "failled" });

            }
        }
        public JsonResult GetbyID(int id)
        {
            var tr = db.Employees.Find(id);
            return Json(tr);
        }
        public JsonResult Delete(int id)
        {
            var tr = db.Employees.Find(id);
            db.Employees.Remove(tr);
            if (db.SaveChanges() > 0)
            {
                return Json(new { result = "Successfully deleted" });
            }
            return Json(new { result = "delete failed" });
        }
        [HttpPost]
        public IActionResult UpdateEmployee(EmployeeVM vm, IEnumerable<IFormFile> files)
        {
            if (!ModelState.IsValid)
            {
                ModelState.AddModelError("", "Invalid Model");
                return View("Index", vm);
            }

            string uploadpath = Path.Combine(hosting.WebRootPath, "images");
            Employee employee = new Employee
            {
                EmployeeName = vm.EmployeeName,
                Gender= vm.Gender,
                DateOfBirth = vm.DateOfBirth,
                Salary = vm.Salary,
                PhoneNumber = vm.PhoneNumber,
                Email = vm.Email,
                ImagePath=vm.ImagePath,
                EmployeeId=vm.EmployeeId
            };
            foreach (var file in files)
            {
                if (file != null && file.Length > 0)
                {
                    var fileName = Guid.NewGuid().ToString() +
                                   file.FileName;
                    using (var s = new FileStream(Path.Combine(uploadpath, fileName),
                                                                FileMode.Create))
                    {
                        file.CopyTo(s);
                        employee.ImagePath = "/images/" + fileName;

                    }
                }
            }


            db.Entry(employee).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            if (db.SaveChanges() > 0)
            {
                return Json(new { result = "success" });
            }
            else
            {
                return Json(new { result = "failled" });

            }
        }
    }
}