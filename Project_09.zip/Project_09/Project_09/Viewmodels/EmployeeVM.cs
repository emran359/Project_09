﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Project_09.Viewmodels
{
    public class EmployeeVM
    {
        public int EmployeeId { get; set; }
        [Required]
        [StringLength(25)]
        [Display(Name = "Employee Name")]
        public string EmployeeName { get; set; }
        public string Gender { get; set; }
        [DataType(DataType.Date)]
        public DateTime DateOfBirth { get; set; }
        public decimal Salary { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public string ImagePath { get; set; }
        
    }
    
}
