﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Project_09.ViewModels
{
    public class ProfileVm
    {
        public string Address { get; set; }
      
        public string Fullname { get; set; }
        public DateTime Dob { get; set; }
        public string ImagePath { get; set; }
        [NotMapped]
        public IFormFile ImgFile { get; set; }
        public string Phonenumber { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public string UserId { get; set; }
        public string Pass { get; set; }

        public string SecStamp { get; set; }
    }
}
