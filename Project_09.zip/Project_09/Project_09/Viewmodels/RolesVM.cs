﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project_09.ViewModels
{
    public class RolesVM
    {
        public string Id { get; set; }
        public string Name { get; set; }

    }
}
