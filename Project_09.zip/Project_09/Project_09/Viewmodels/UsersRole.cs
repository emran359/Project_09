﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project_09.ViewModels
{
    public class UsersRole
    {
        public string UserID { get; set; }
        public string UserName { get; set; }
        public string RoleName { get; set; }

    }
}
